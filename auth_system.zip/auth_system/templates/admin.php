<?php
require_once '../helpers/session.php';

if (!isAdmin()) {
    header('Location: /login.html');
    exit();
}

$title = "Admin Dashboard";
ob_start();
?>
<h2>Admin Dashboard</h2>
<p>Manage users and view system stats.</p>
<?php
$content = ob_get_clean();
include 'base.php';
?>
