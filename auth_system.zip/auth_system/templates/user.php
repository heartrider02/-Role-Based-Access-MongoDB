<?php
require_once '../helpers/session.php';

if (!isAuthenticated()) {
    header('Location: /login.html');
    exit();
}

$title = "User Dashboard";
ob_start();
?>
<h2>User Dashboard</h2>
<p>Welcome, <?php echo $_SESSION['user']['username']; ?>!</p>
<?php
$content = ob_get_clean();
include 'base.php';
?>
