<?php
session_start();

function isAuthenticated() {
    return isset($_SESSION['user']);
}

function isAdmin() {
    return isAuthenticated() && $_SESSION['user']['role'] === 'admin';
}

function destroySession() {
    session_destroy();
}
?>
