<?php
require_once '../config/db.php';
require_once '../helpers/session.php';
require_once '../helpers/error.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['email']) || !isset($data['password'])) {
    sendErrorResponse(400, "Missing required fields");
}

$collection = getAuthSystemDB()->users;

// Check if the email exists
$user = $collection->findOne(['email' => $data['email']]);

if (!$user || !password_verify($data['password'], $user['password'])) {
    sendErrorResponse(401, "Invalid email or password");
}

// Start the session and store user details
session_start();
$_SESSION['user'] = [
    'id' => (string) $user['_id'],
    'username' => $user['username'],
    'email' => $user['email'],
    'role' => $user['role']
];

echo json_encode(['message' => 'Login successful', 'role' => $user['role']]);
?>
