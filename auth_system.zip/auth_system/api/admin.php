<?php
require_once '../helpers/session.php';
require_once '../helpers/error.php';

if (!isAdmin()) {
    sendErrorResponse(403, "Forbidden: Admin access only");
}

echo json_encode(['message' => 'Welcome to the Admin Dashboard']);
?>
