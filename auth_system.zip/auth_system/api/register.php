<?php
require_once '../config/db.php';
require_once '../helpers/error.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['username']) || !isset($data['email']) || !isset($data['password'])) {
    sendErrorResponse(400, "Missing required fields");
}

$collection = getAuthSystemDB()->users;

// Check if the email already exists
$existingUser = $collection->findOne(['email' => $data['email']]);
if ($existingUser) {
    sendErrorResponse(400, "Email is already registered");
}

// Hash the password before saving
$hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);

// Insert user into MongoDB
$insertResult = $collection->insertOne([
    'username' => $data['username'],
    'email' => $data['email'],
    'password' => $hashedPassword,
    'role' => 'user' // Default role is 'user'
]);

if ($insertResult->getInsertedCount() == 1) {
    echo json_encode(['message' => 'User registered successfully']);
} else {
    sendErrorResponse(500, "Error registering user");
}
?>
