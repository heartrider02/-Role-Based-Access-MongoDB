<?php
require_once '../helpers/session.php';

destroySession();

header('Content-Type: application/json');
echo json_encode(['message' => 'Logged out successfully']);
?>
