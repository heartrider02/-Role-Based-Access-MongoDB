<?php
require_once '../helpers/session.php';
require_once '../helpers/error.php';

if (!isAuthenticated()) {
    sendErrorResponse(401, "Unauthorized");
}

$user = $_SESSION['user'];
echo json_encode([
    'username' => $user['username'],
    'email' => $user['email']
]);
?>
