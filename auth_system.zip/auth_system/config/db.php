<?php
require_once __DIR__ . '/../vendor/autoload.php';

function getMongoClient() {
    try {
        // Connection string with replaced password
        $client = new MongoDB\Client("mongodb+srv://Project:Ar\$hath@321@cluster0.nktsp.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0");
        return $client;
    } catch (Exception $e) {
        die("Error connecting to MongoDB: " . $e->getMessage());
    }
}

function getAuthSystemDB() {
    $client = getMongoClient();
    return $client->auth_system; // Database name: auth_system
}
